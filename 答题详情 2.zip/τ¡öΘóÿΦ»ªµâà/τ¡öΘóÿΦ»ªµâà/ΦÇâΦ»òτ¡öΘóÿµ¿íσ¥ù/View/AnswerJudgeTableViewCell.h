//
//  AnswerJudgeTableViewCell.h
//  答题详情
//
//  Created by 冯垚杰 on 2017/6/28.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuestionListModel.h"

@interface AnswerJudgeTableViewCell : UITableViewCell // 判断选项


- (void)setModel:(QuestionListModel *)model index:(NSInteger)index;

@end
