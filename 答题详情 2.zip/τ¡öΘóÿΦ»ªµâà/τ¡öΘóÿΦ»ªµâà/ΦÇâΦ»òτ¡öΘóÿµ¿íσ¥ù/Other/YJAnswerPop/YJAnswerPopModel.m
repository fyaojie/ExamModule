//
//  YJAnswerPopModel.m
//  MYPresentation
//
//  Created by 冯垚杰 on 2017/7/3.
//  Copyright © 2017年 qc. All rights reserved.
//

#import "YJAnswerPopModel.h"

@implementation YJAnswerPopModel

@end
