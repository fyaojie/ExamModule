//
//  ViewController.h
//  MYPresentation
//
//  Created by qc on 2017/5/3.
//  Copyright © 2017年 qc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYColorBackView : UIView

//背景颜色View
@property (nonatomic, strong) UIView *backColorView;
//占位
@property (nonatomic, strong) UIView *topView;

@end
