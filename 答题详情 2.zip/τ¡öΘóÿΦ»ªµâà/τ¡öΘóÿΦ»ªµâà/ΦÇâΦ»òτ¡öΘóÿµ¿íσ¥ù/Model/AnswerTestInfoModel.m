//
//  AnswerTestInfoModel.m
//  LearnFriendEnterprise
//
//  Created by 冯垚杰 on 2017/6/28.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import "AnswerTestInfoModel.h"

@implementation AnswerTestInfoModel

@end
