//
//  AnswerModel.m
//  LearnFriendEnterprise
//
//  Created by 冯垚杰 on 2017/6/28.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import "AnswerModel.h"

@implementation AnswerModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"categoryQuestionList":@"CategoryQuestionListModel"};
}

@end
