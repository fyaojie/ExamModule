//
//  TestTypeModel.h
//  LearnFriendEnterprise
//
//  Created by 冯垚杰 on 2017/6/28.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestTypeModel : NSObject
@property (nonatomic, strong) NSString * code;
@property (nonatomic, assign) NSInteger id;
@property (nonatomic, strong) NSString * labeldescription;
@property (nonatomic, strong) NSString * labelname;

@end
